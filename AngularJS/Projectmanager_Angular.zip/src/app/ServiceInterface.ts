export class tabledata {
    Application_Name: string;
    Source: string;
    Error_Description: string;
    Comment_Text: string;
    Error_Module: string;
    Error_Date: string;
}